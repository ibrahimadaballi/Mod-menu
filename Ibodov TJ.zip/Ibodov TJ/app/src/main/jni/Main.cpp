/*
 * Credits:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */
#include <list>
#include <vector>
#include <string.h>
#include <sys/types.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include "ESP/ESP.h"
#include "ESP/Hacks.h"
#include "Includes/obfuscate.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "Menu.h"

//#endif

using namespace std;

ESP espOverlay;

//void DrawESP(ESP esp, int screenWidth, int screenHeight) {

    //esp.DrawCrosshair(Color::Green(), Vector2(screenWidth / 2, screenHeight / 2), 42);
	
	//esp.DrawCircle(Color(0, 0, 0, 255), Vector2(screenWidth / 2, screenHeight / 50),50);
	
	//esp.DrawText(Color::Green(), "", Vector22(screenWidth / 2, screenHeight / 1.03f), 20.0f);



#if defined(__aarch64__) //Compile for arm64 lib only
#include <And64InlineHook/And64InlineHook.hpp>
#else //Compile for armv7 lib only. Do not worry about greyed out highlighting code, it still works

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>
#include <iostream>

#endif

// fancy struct for patches for kittyMemory





struct My_Patches {
    MemoryPatch Mod1;
	
	
	
	
    
    
} hexPatches;
bool Mod1 = false;





//bool blue = false; //

#define targetLibName OBFUSCATE("libUE4.so")

extern "C" {
JNIEXPORT void JNICALL
Java_rubel_mod_menu_FloatingModMenuService_DrawOl(JNIEnv *env, jclass , jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

extern "C" 
JNIEXPORT void JNICALL
Java_rubel_mod_menu_ESPView_DrawESP(JNIEnv *env, jobject thiz) {
    // TODO: implement DrawESP()
    //DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    
}

extern "C" 
JNIEXPORT void JNICALL
Java_rubel_mod_MainActivity_Toast(JNIEnv *env, jclass obj, jobject context) {
    MakeToast(env, context, OBFUSCATE("WELCOME TO MOD MENU"), Toast::LENGTH_LONG);
}

// Note:
// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// To learn HTML, go to this page: https://www.w3schools.com/

// Usage:
// (Optional feature number)_Toggle_(feature name)
// (Optional feature number)_SeekBar_(feature name)_(min value)_(max value)
// (Optional feature number)_Spinner_(feature name)_(Items e.g. item1,item2,item3)
// (Optional feature number)_Button_(feature name)
// (Optional feature number)_ButtonOnOff_(feature name)
// (Optional feature number)_InputValue_(feature name)
// (Optional feature number)_CheckBox_(feature name)
// (Optional feature number)_RadioButton_(feature name)_(Items e.g. radio1,radio2,radio3)
// RichTextView_(Text with limited HTML support)
// RichWebView_(Full HTML support)
// ButtonLink_(feature name)_(URL/Link here)
// Category_(text)

// Few examples:
// 10_Toggle_Jump hack
// 100_Toggle_Ammo hack
// Toggle_Ammo hack
// 1_Spinner_Weapons_AK47,9mm,Knife
// Spinner_Weapons_AK47,9mm,Knife
// 2_ButtonOnOff_God mode
// Category_Hello world

JNIEXPORT jobjectArray
JNICALL
Java_rubel_mod_menu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
		
		
		
		
		
		
		
		
		    
			OBFUSCATE("1_Toggle_➣ BYPASS ANY LOGO"),//1
		    
    };

	
	
	
	
	
	
	
	
	
	
    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}

JNIEXPORT void JNICALL
Java_rubel_mod_menu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean jboolean1, jstring str) {
    //Convert java string to c++
    const char *featureName = env->GetStringUTFChars(featName, 0);
    const char *TextInput;
    if (str != NULL)
        TextInput = env->GetStringUTFChars(str, 0);
    else
        TextInput = "Empty";

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         featureName, value,
         jboolean1, TextInput);

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        

		
		
		
		
		
		
		
			
         case 1:
            Mod1 = jboolean1;
            if (Mod1) {
                hexPatches.Mod1.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.Mod1.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;           
            }
			
			
			
			
			
			
			
                         
}
}

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

	
	
	
	
	
	
	
	
    hexPatches.Mod1 = MemoryPatch::createWithHex(targetLibName,
                                                string2Offset(OBFUSCATE_KEY("0x2724F30", '-')),
                                                OBFUSCATE("00 00 00 00"));                                               
    


                                            
                                        
												
												
												
												
                                                                                                  
         
    return NULL;
}

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}


JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    return JNI_VERSION_1_6;
}
 
