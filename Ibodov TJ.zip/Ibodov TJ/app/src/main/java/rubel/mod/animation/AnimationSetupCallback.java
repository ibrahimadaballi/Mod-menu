package rubel.mod.animation;

import rubel.mod.menu.FloatingModMenuService;

public interface AnimationSetupCallback {
    public void onSetupAnimation(TitanicTextView titanicTextView);
    public void onSetupAnimation(TitanicButton Button);
}

